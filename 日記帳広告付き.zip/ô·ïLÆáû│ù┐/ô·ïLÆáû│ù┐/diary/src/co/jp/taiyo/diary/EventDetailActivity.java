package co.jp.taiyo.diary;

import java.util.ArrayList;

import jp.rinad.sp.RinAd;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;

/**
 * ���̓��ɏ��������L�����ׂĕ\�����郊�X�g���쐬����N���X�ł�
 * @author kondo
 *
 */
public class EventDetailActivity extends Activity implements OnItemLongClickListener{
	private String mDateString = null;
	public static final int EVENT_EDITOR = 3;
	private ListView mEventListView = null;
	static TaskAdapter adapter = null;
	private ArrayList<EventInfo> tasks;

	private final String className = "EventDetailActivity";

	public void onCreate(Bundle savedInstanceState) {
		final String methodName = "onCreate";

		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.eventdetail);
		setActionBar();

		final RinAd ad = (RinAd) findViewById(R.id.RinAd);
		ad.enableView();

		//�O�̉�ʂ���l�������p���܂�
		Intent intent = getIntent();
		mDateString = intent.getStringExtra("date");


		mEventListView = (ListView) findViewById(R.id.eventList);
		tasks = getEventDetail(mDateString);

		adapter = new TaskAdapter(this, R.layout.main, tasks);
		mEventListView.setAdapter(adapter);

		// eventListView�̃A�C�e�����N���b�N���ꂽ���̏������Z�b�g
		mEventListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
				Intent intent = new Intent(EventDetailActivity.this, DialyDay.class);
				EventInfo event = (EventInfo)parent.getAdapter().getItem(position);


				intent.putExtra(EventInfo.COL_ID, event.getId());
				intent.putExtra("date",mDateString);



				try {
					startActivityForResult(intent,EVENT_EDITOR);
					Log.d(className, methodName + "::ID =" + event.getId());
					finish();
				} catch (ActivityNotFoundException e) {
					Log.e(className, methodName + "::ActivityNotFoundException e =" + e.getMessage());
				}

			}
		});
	    mEventListView.setOnItemLongClickListener(this);
	}




	/**
	 * �^�C�g���o�[��ݒ肵�Ă��܂�
	 */
	private void setActionBar() {
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.action_bar3);

		//�J�X�^���^�C�g���̃Z�b�g�A�b�v
		TextView mTitle;
		mTitle = (TextView) findViewById(R.id.title_text);
		mTitle.setText(getString(R.string.app_name));

		//�{�^��
		Button mButton;
		mButton = (Button) findViewById(R.id.return_btn);
		mButton.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				Intent intent = new Intent(EventDetailActivity.this, CalenderActivity.class);
				startActivity(intent);
				finish();

			}
		});

	}


/**
 * �I���������̓��L�����ׂĎ擾���܂��B
 *
 * @param date �I��������
 * @return ���L����t�Ȃ�
 */
	private ArrayList<EventInfo> getEventDetail(String date) {
		ArrayList<EventInfo> events = new ArrayList<EventInfo>();

		ContentResolver contentResolver = getContentResolver();
		String selection = EventInfo.COL_START_TIME + " LIKE ?";
		String[] selectionArgs = {mDateString+"%"};
		String sortOrder = EventInfo.COL_START_TIME;
		Cursor c = contentResolver.query(CalenderActivity.RESOLVER_URI, null, selection, selectionArgs, sortOrder);



		while(c.moveToNext()) {

			EventInfo event = new EventInfo();

			event.setId(c.getLong(c.getColumnIndex(EventInfo.COL_ID)));
			event.setDiary(c.getString(c.getColumnIndex(EventInfo.COL_DIARY)));
			event.setStart(c.getString(c.getColumnIndex(EventInfo.COL_START_TIME)));
			event.setRat(c.getInt(c.getColumnIndex(EventInfo.COL_RAT)));
			event.setHeart(c.getString(c.getColumnIndex(EventInfo.COL_HEART)));

			events.add(event);
		}



		c.close();
		return events;


	}


	/**
	 * ���X�g�A�_�v�^�̍X�V�����܂�
	 */
	private void setListAdapter(){
		mEventListView.setAdapter(new ArrayAdapter<EventInfo>(this,android.R.layout.simple_list_item_1,getEventDetail(mDateString)));
	}

	/**
	 * ���L�̏ڍ׉�ʂ���߂��Ă����ꍇ�̌��ʕ\���p�ł��B
	 * �ύX���������ꍇ�ɁACalenderActivity�ɂ��ʒm���Ă��܂�
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == EVENT_EDITOR && resultCode == RESULT_OK) {
			if (data.getBooleanExtra(CalenderActivity.CHANGED, false)) {
				setListAdapter();

				tasks = getEventDetail(mDateString);

				adapter = new TaskAdapter(this, R.layout.main, tasks);
				mEventListView.setAdapter(adapter);

				Intent intent = new Intent();
				intent.putExtra(CalenderActivity.CHANGED, true);
				setResult(RESULT_OK, intent);

			}
		}
	}

	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		return false;
	}

	static class ViewHolder {
		TextView month;
		TextView day;
		TextView dayofweek;
		TextView diary;
		RatingBar rat;

	}

	public class TaskAdapter extends ArrayAdapter {

		private ArrayList<EventInfo> items;
		private LayoutInflater inflater;

		public TaskAdapter(Context context, int textViewResorceId, ArrayList<EventInfo> items) {
			super(context, textViewResorceId, items);

			this.items = items;
			this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		}

		public void insert(String str, int position) {
			super.insert(str, position);
		}

		public void remove(String str) {
			super.remove(str);
		}

		public void add(String str) {
			super.add(str);
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			View view = convertView;

			if (view == null) {
				view = inflater.inflate(R.layout.main, null);

			}

			EventInfo item = (EventInfo) items.get(position);
			if (item != null) {
				holder = new ViewHolder();
				holder.month = (TextView) view.findViewById(R.id.list_month);
				holder.month.setText(item.getMonth(mDateString));

				holder.day = (TextView) view.findViewById(R.id.list_day);
				holder.day.setText(item.getDay(mDateString));

				holder.dayofweek = (TextView) view.findViewById(R.id.list_day_of_the_week);
				holder.dayofweek.setText(item.getWeekOfDay(mDateString));

				holder.rat = (RatingBar) view.findViewById(R.id.list_rating);
				holder.rat.setRating(item.getRat());

				holder.diary = (TextView) view.findViewById(R.id.list_diary);
				holder.diary.setText(item.getDiary());
			}

			return view;
		}



	}

}
