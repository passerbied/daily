package co.jp.taiyo.diary;

import java.util.Calendar;
import java.util.Date;

import android.util.Log;



public class TextArrayItem {

	private String diary;
	private String month;
	private String day;
	private String dayofweek;
	private String rat;
	private String lastupdate;
	private String heart;

	public TextArrayItem(int id, String diary, String lastupdate, String rat, String heart) {
		this.diary = diary;
		this.lastupdate = lastupdate;
		this.rat = rat;
		this.heart = heart;
	}

	public String getDiary() {
		return diary;
	}

	public void setDiary(String diary) {
		this.diary = diary;
	}

	public String getLastupdate() {
		return lastupdate;
	}



	public String getMonth(String lastupdate) {
		String mMonth = lastupdate.substring(5, 7);

		return changeMonthName(mMonth);
	}

	private String changeMonthName(String month) {
		String changeMonth = null;
		int i;
		if (month.equals("07")) {
			i = 7;
		} else if (month.equals("08")) {
			i = 8;
		} else if (month.equals("09")) {
			i = 9;
		} else {
			i = Integer.parseInt(month);
		}

		switch(i) {
		case 01:
			changeMonth = "Jan";
			break;
		case 02:
			changeMonth = "Feb";
			break;
		case 03:
			changeMonth = "Mar";
			break;
		case 04:
			changeMonth = "Apr";
			break;
		case 05:
			changeMonth = "May";
			break;
		case 06:
			changeMonth = "Jun";
			break;
		case 7:
			changeMonth = "Jul";
			break;
		case 8:
			changeMonth = "Aug";
			break;
		case 9:
			changeMonth = "Sep";
			break;
		case 10:
			changeMonth = "Oct";
			break;
		case 11:
			changeMonth = "Nov";
			break;
		case 12:
			changeMonth = "Dec";
			break;

		}
		return changeMonth;
	}


	public String getDay(String lastupdate) {
		return lastupdate.substring(8, 10);
	}


	public String getDayOfWeek(String lastupdate) {

		return getDayofTheWeek(lastupdate);
	}


	public float getRatingBar() {

		return Float.parseFloat(rat);
	}

	public void setRatingBar(String rat) {
		this.rat = rat;
	}

	public String getYear(String lastupdate) {
		return lastupdate.substring(0, 4);
	}

	private String getDayofTheWeek(String lastupdate) {
		int year = Integer.parseInt(getYear(lastupdate));
		int month = Integer.parseInt(lastupdate.substring(5, 7));
		int day = Integer.parseInt(getDay(lastupdate));

		if (month < 3) {
			year --;
			month += 12;
		}
		int weeknum = (year + (year / 4) - (year / 100) + (year / 400) + ((month * 13 + 8) / 5) + day) % 7;

		switch(weeknum + 1) {
		case Calendar.SUNDAY:
			return "Sunday";
		case Calendar.MONDAY:
			return "Monday";
		case Calendar.TUESDAY:
			return "Tuesday";
		case Calendar.WEDNESDAY:
			return "Wednesday";
		case Calendar.THURSDAY:
			return "Thursday";
		case Calendar.FRIDAY:
			return "Fryday";
		case Calendar.SATURDAY:
			return "Saturday";
		}
		return null;

	}


}
