package co.jp.taiyo.diary;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;



public class MainActivity extends Activity {

	private EditText edit;
	private int REQUEST_RECOGNIZE = 1;
	private RatingBar rat;
	private TextView date;
	private TextView time;
	private TextView day;
	private TextView year;
	private Calendar nowCal;

	// IntentでもらったデータベースID
	private long mId = 0;
	// 日付の文字列
	private String mDateString = null;

	protected static final int EVENT_DETAIL = 2;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.input_list);
		setActionBar();

		edit = (EditText) findViewById(R.id.diary_edit);
		rat = (RatingBar) findViewById(R.id.ratingbar);
		date = (TextView) findViewById(R.id.input_date);
		time = (TextView) findViewById(R.id.input_time);
//		day = (TextView) findViewById(R.id.input_day);
//		year = (TextView) findViewById(R.id.input_year);


		Intent intent = getIntent();
		mId = intent.getLongExtra(EventInfo.COL_ID, 0);
		mDateString = intent.getStringExtra("date");

		Calendar targetCal = EventInfo.toCalendar(mDateString);
		nowCal = new GregorianCalendar();

		String fdate = EventInfo.dateFormat.format(targetCal.getTime());
		EventInfo.getsMonth(fdate);

		date.setText(fdate.substring(8) + " " + EventInfo.getsMonth(fdate) + " " + fdate.substring(0, 4));

		time.setText(EventInfo.timeFormat.format(nowCal.getTime()));


		Button rec = (Button) findViewById(R.id.recognize_button);
		rec.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				RecodingVoice(v);

			}
		});

	}

	private void setActionBar() {
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.action_bar);

		//カスタムタイトルのセットアップ
		TextView mTitle;
		mTitle = (TextView) findViewById(R.id.title_text);
		mTitle.setText(getString(R.string.app_name));

		//Save
		Button mButton;
		mButton = (Button) findViewById(R.id.diary_input_button);
		mButton.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				ContentResolver contentResolver = getContentResolver();
				ContentValues values = new ContentValues();

				values.put(EventInfo.COL_DIARY, edit.getText().toString());
				values.put(EventInfo.COL_START_TIME, EventInfo.toDBDateString(mDateString, EventInfo.timeFormat.format(nowCal.getTime())));
				values.put(EventInfo.COL_RAT, Float.toString(rat.getRating()));
				values.put(EventInfo.COL_HEART, "♡");

				contentResolver.insert(CalenderActivity.RESOLVER_URI, values);

				Intent intent = new Intent(MainActivity.this, CalenderActivity.class);
				intent.putExtra(CalenderActivity.CHANGED, true);
				setResult(RESULT_OK, intent);

				startActivityForResult(intent, EVENT_DETAIL);
				finish();
			}
		});


	}



	private void RecodingVoice(View v) {
		Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
		intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
		intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,R.string.recognaized);
		startActivityForResult(intent, REQUEST_RECOGNIZE);

	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		if (requestCode == REQUEST_RECOGNIZE && resultCode == RESULT_OK) {
			String speakedString = "";

			ArrayList<String> speechToChar = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
			if (speechToChar.size() > 0) {
				speakedString = speechToChar.get(0);
			}
			if (speakedString != null) {
				edit.setText(speakedString);
				edit.setSelection(speakedString.length());
			}

		}
	}



	public void sendToTwitter() {
		String message = getResources().getString(R.string.share);
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_SEND);
		intent.setType("text/plain");
		intent.putExtra(Intent.EXTRA_TEXT, message);
		startActivity(intent);
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);

		return true;
	}

	public boolean onOptionsItemSelected(MenuItem item) {

		switch(item.getItemId()) {
			case R.id.menu_preference:
				Intent alarm_intent = new Intent(getApplicationContext(), AlarmProvider.class);
				startActivity(alarm_intent);

				return true;
			case R.id.menu_share:
				sendToTwitter();
				return true;

		}
		return false;
	}

}
