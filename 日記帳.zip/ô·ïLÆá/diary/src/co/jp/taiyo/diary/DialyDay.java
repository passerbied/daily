package co.jp.taiyo.diary;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

/**
 * ������̏ڍׂȓ��L�\�������܂�
 * @author kondo
 *
 */
public class DialyDay extends Activity{

	private RatingBar rat;
	private TextView diary;
	private String mDate;
	private long mId;

	final private String className = "DialyDay";

	public void onCreate(Bundle savedInstanceState) {
		final String methodName = "onCreate";

		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.day);
		setActionBar();

		//�O�̉�ʂ�������p���l���擾���܂�
		Bundle extras = getIntent().getExtras();

		if (extras != null) {
			mId = extras.getLong(EventInfo.COL_ID);
			mDate = extras.getString("date");

			TextView mDay = (TextView) findViewById(R.id.edit_day);
			mDay.setText(mDate.substring(8, 10));

			TextView mDayofWeek = (TextView) findViewById(R.id.edit_dayofweek);
			mDayofWeek.setText(EventInfo.getSWeekOfDay(mDate));

			TextView mMonth = (TextView) findViewById(R.id.edit_month);
			mMonth.setText(EventInfo.getsMonth(mDate));

			TextView mYear = (TextView) findViewById(R.id.edit_year);
			mYear.setText(mDate.substring(0, 4));

			rat = (RatingBar) findViewById(R.id.rating_bar);
			diary = (TextView) findViewById(R.id.edit_diary);

			//���L�ƃ��[�g���擾���܂�
			getDairy();
		}


		Log.d(className, methodName + ":: ID = " + mId);

	}

	/**
	 * �^�C�g���o�[��ݒ肵�Ă��܂�
	 */
	private void setActionBar() {
		final String methodName = "setActionBar";

		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.action_bar4);

		//�J�X�^���^�C�g���̃Z�b�g�A�b�v
		TextView mTitle;
		mTitle = (TextView) findViewById(R.id.title_text);
		mTitle.setText(getString(R.string.app_name));

		//�{�^��
		Button mButton;
		mButton = (Button) findViewById(R.id.return_btn3);
		mButton.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				Intent intent = new Intent(DialyDay.this, EventDetailActivity.class);
				intent.putExtra(EventInfo.COL_ID, mId);
				intent.putExtra("date",mDate);

				try {
					startActivity(intent);
					finish();

				} catch (ActivityNotFoundException e) {
					Log.e(className, methodName + "::ActivityNotFoundException e =" + e.getMessage());
				}

			}
		});

	}

	/**
	 * ���L�ƃ��[�g���擾���܂��B
	 */
	private void getDairy() {

		ContentResolver contentResolver = getContentResolver();
		StringBuilder where = new StringBuilder();
		where.append(EventInfo.COL_ID).append("==").append(mId);
		String selection = where.toString();

		Cursor c = contentResolver.query(CalenderActivity.RESOLVER_URI, null, selection, null, null);

		while(c.moveToNext()) {
			rat.setRating(c.getFloat(c.getColumnIndex(EventInfo.COL_RAT)));
			diary.setText(c.getString(c.getColumnIndex(EventInfo.COL_DIARY)));

		}
		c.close();


	}


}
