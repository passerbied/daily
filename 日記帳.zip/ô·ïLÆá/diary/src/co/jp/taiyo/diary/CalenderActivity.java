package co.jp.taiyo.diary;

import java.util.Calendar;
import java.util.GregorianCalendar;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

/**
 * カレンダー表示をしているクラスです
 * @author kondo
 *
 */
public class CalenderActivity extends Activity implements OnClickListener{


	// 一週間の日数
	private static final int DAYS_OF_WEEK = 7;
	// GridViewのインスタンス
	private GridView mGridView = null;
	// DateCellAdapterのインスタンス
	private DateCellAdapter mDateCellAdapter = null;
	// 現在注目している年月日を保持する変数
	private GregorianCalendar mCalendar = null;
	// カレンダーの年月を表示するTextView
	private TextView mYearMonthTextView = null;
	// ContentResolverのインスタンス
	private ContentResolver mContentResolver = null;
	// EventProviderのUri
	public static final Uri RESOLVER_URI = Uri.parse("content://co.jp.taiyo.diary.eventprovider");
	// EventDetailActivityを呼び出すためのrequestコード
	protected static final int EVENT_DETAIL = 2;
	// 前月ボタンのインスタンス
	private Button mPrevMonthButton = null;
	// 次月ボタンのインスタンス
	private Button mNextMonthButton = null;
	// Activityでデータベースが更新されたことを伝えるためのタグ
	public static final String CHANGED = "changed";

	private final String className = "CalenderActivity";

	public void onCreate(Bundle savedInstanceState) {

		final String methodName = "onCreate";
		Log.d(className, methodName);

		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.calendar);
		setActionBar();

		mGridView = (GridView)findViewById(R.id.gridView1);
		mGridView.setNumColumns(DAYS_OF_WEEK);
		mDateCellAdapter = new DateCellAdapter(this);
		mGridView.setAdapter(mDateCellAdapter);

		//タップされたカレンダーの場所を求めます
		mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			public void onItemClick(AdapterView<?> parent, View v, int position,long id) {

				Calendar cal = (Calendar)mCalendar.clone();
				// positionから日付を計算
				cal.set(Calendar.DAY_OF_MONTH, 1);
				cal.add(Calendar.DAY_OF_MONTH, position-cal.get(Calendar.DAY_OF_WEEK)+1);

				// 日付文字列を生成
				String dateString = EventInfo.dateFormat.format(cal.getTime());
				Intent intent = new Intent(CalenderActivity.this,EventDetailActivity.class);
				intent.putExtra("date", dateString);

				try {
					// Activityを実行
					startActivityForResult(intent,EVENT_DETAIL);
					finish();

				}catch (ActivityNotFoundException e) {
					Log.e(className, "onItemClick::ActivityNotFoundException e =" + e.getMessage());
				}
			}
		});

		mYearMonthTextView = (TextView)findViewById(R.id.yearMonth);
		mCalendar = new GregorianCalendar();

		int year = mCalendar.get(Calendar.YEAR);
		int month = mCalendar.get(Calendar.MONTH)+1;

		mYearMonthTextView.setText(year+" "+getMonth(month));
		mContentResolver = getContentResolver();

		mPrevMonthButton = (Button)findViewById(R.id.prevMonth);
		mPrevMonthButton.setOnClickListener(this);

		mNextMonthButton = (Button)findViewById(R.id.nextMonth);
		mNextMonthButton.setOnClickListener(this);

		//すでに入力されている予定をDBにアクセスして取得
		Cursor c = mContentResolver.query(RESOLVER_URI,null,null,null,null);
		Log.d("CALENDAR","Num of records:"+ c.getCount());
		c.close();


	}

	/**
	 * 数字→月名変換してます
	 * @param smonth 月
	 * @return 月名
	 */
	private String getMonth(int smonth) {

		String month = null;

		switch(smonth) {
		case 1:
			month = "January";
			break;
		case 2:
			month = "February";
			break;
		case 3:
			month = "March";
			break;
		case 4:
			month = "April";
			break;
		case 5:
			month = "May";
			break;
		case 6:
			month = "June";
			break;
		case 7:
			month = "July";
			break;
		case 8:
			month = "August";
			break;
		case 9:
			month = "September";
			break;
		case 10:
			month = "October";
			break;
		case 11:
			month = "November";
			break;
		case 12:
			month = "December";
			break;
		}

		return month;

	}


	/**
	 * タイトルバーの設定をしています
	 */
	private void setActionBar() {

		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.action_bar2);

		//カスタムタイトルのセットアップ
		TextView mTitle;
		mTitle = (TextView) findViewById(R.id.title_text);
		mTitle.setText(getString(R.string.app_name));

		//Write
		Button mButton;
		mButton = (Button) findViewById(R.id.diary_input_button);
		mButton.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				//今日の日付を生成する
				Calendar cal = Calendar.getInstance();

				// 日付文字列を生成
				String dateString = EventInfo.dateFormat.format(cal.getTime());

				Intent intent = new Intent(getApplicationContext(), MainActivity.class);
				intent.putExtra(EventInfo.COL_ID, 0);
				intent.putExtra("date", dateString);
				startActivityForResult(intent,0);

			}
		});



	}


	/**
	 * onClick
	 *  前月、次月ボタンでクリックされたとき呼び出される
	 */
	public void onClick(View v) {
		mCalendar.set(Calendar.DAY_OF_MONTH,1);

		if(v == mPrevMonthButton){
			mCalendar.add(Calendar.MONTH, -1);
		}else if(v == mNextMonthButton){
			mCalendar.add(Calendar.MONTH, 1);
		}

		mYearMonthTextView.setText(mCalendar.get(Calendar.YEAR)+" " + getMonth(mCalendar.get(Calendar.MONTH)+1));
		mDateCellAdapter.notifyDataSetChanged();

	}

	/**
	 * onActivityResult
	 *  呼び出したEditorの処理が完了したとき呼び出される
	 * @param requestCode 起動時に指定したrequestCode
	 * @param resultCode 呼び出したActivityが終了時に設定した終了コード
	 * @param data 呼び出したActivityが終了時に設定したIntent
	 */
	protected void onActivityResult (int requestCode, int resultCode, Intent data) {
		if(requestCode == EVENT_DETAIL && resultCode == RESULT_OK){

			if(data.getBooleanExtra(CalenderActivity.CHANGED, true)){
				// EVENT_DETAILの処理結果がOKでChangedがtrueなら、データベース更新を通知
				mDateCellAdapter.notifyDataSetChanged();



			}
		}
	}

	/**
	 * DateCellAdapterクラス
	 *  BaseAdapterを継承する。
	 */
	public class DateCellAdapter extends BaseAdapter {
		private static final int NUM_ROWS = 5;
		private static final int NUM_OF_CELLS = DAYS_OF_WEEK*NUM_ROWS;
		private LayoutInflater mLayoutInflater = null;
		/**
		 * コンストラクタではパラメタで受け取ったcontextを使用して
		 * 「LayoutInflater」のインスタンスを作成する。
		 * @param context アクティビティ
		 */
		DateCellAdapter(Context context){
			// getSystemServiceでContextからLayoutInflaterを取得
			mLayoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}
		/**
		 * getCount
		 * 「NUM_OF_CELLS」 (42)を返す
		 */
		public int getCount() {
			return NUM_OF_CELLS;
		}
		/**
		 * getItem
		 * 必要ないのでnullを返す
		 */
		public Object getItem(int position) {
			return null;
		}
		/**
		 * getItemId
		 * 必要ないので0を返す
		 */
		public long getItemId(int position) {
			return 0;
		}




		/**
		 * getView
		 *  DateCellのViewを作成して返すためのメソッド
		 *  @param int position セルの位置
		 *  @param View convertView 前に使用したView
		 *  @param ViewGroup parent 親ビュー　ここではGridView
		 */
		public View getView(int position, View convertView, ViewGroup parent) {
			if(convertView == null){
				convertView = mLayoutInflater.inflate(R.layout.datecell,null);
			}
			// Viewの最小の高さを設定する
			convertView.setMinimumHeight(parent.getHeight()/NUM_ROWS-1);
			TextView dayOfMonthView = (TextView)convertView.findViewById(R.id.dayOfMonth);

			Calendar cal = (Calendar)mCalendar.clone();
			cal.set(Calendar.DAY_OF_MONTH, 1);
			cal.add(Calendar.DAY_OF_MONTH, position-cal.get(Calendar.DAY_OF_WEEK)+1);
			dayOfMonthView.setText(""+cal.get(Calendar.DAY_OF_MONTH));

			if(position%7 == 0){

				dayOfMonthView.setBackgroundResource(R.color.red);

			}else if(position%7 == 6){

				dayOfMonthView.setBackgroundResource(R.color.saxe_blue);

			}else {

				dayOfMonthView.setBackgroundResource(R.color.white);

			}

			TextView scheduleView = (TextView)convertView.findViewById(R.id.schedule);

			String[] projection = {EventInfo.COL_HEART};
			String selection = EventInfo.COL_START_TIME + " LIKE ?";
			String[] selectionArgs = {EventInfo.dateFormat.format(cal.getTime()) + "%"};
			String sortOrder = EventInfo.COL_START_TIME;

			Cursor c = mContentResolver.query(RESOLVER_URI, projection, selection, selectionArgs, sortOrder);

			StringBuilder sb = new StringBuilder();

			while(c.moveToNext()) {

				sb.append(c.getString(c.getColumnIndex(EventInfo.COL_HEART)));
				sb.append("\n");

			}

			c.close();
			scheduleView.setText(sb.toString());



			return convertView;
		}
	}


	/**
	 * メニューを呼びます
	 */
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu2, menu);

		return true;
	}

	/**
	 * メニューリストを表示します
	 */
	public boolean onOptionsItemSelected(MenuItem item) {

		switch(item.getItemId()) {
		case R.id.menu_preference:
			Intent alarm_intent = new Intent(getApplicationContext(), AlarmProvider.class);
			startActivity(alarm_intent);

			return true;

		}
		return false;
	}

}
