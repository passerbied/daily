package co.jp.taiyo.diary;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * �A���[���̃��V�[�u�N���X�ł��B
 * nofitication�Œʒm�������ƁAnotification���^�b�v���ċN������A�N�e�B�r�e�B��ݒ肵�Ă܂�
 * @author kondo
 *
 */
public class ReceivedActivity extends BroadcastReceiver{

	private int number = 0;

	@Override
	public void onReceive(Context context, Intent intent) {

		NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
		Notification notification = new Notification();

		Intent setIntent = new Intent(context, CalenderActivity.class);
		PendingIntent pi = PendingIntent.getActivity(context, 0, setIntent, 0);

		notification.icon = R.drawable.bookmark;
		notification.tickerText = context.getResources().getString(R.string.app_name);
		notification.number = number;


		notification.defaults |= Notification.DEFAULT_LIGHTS;
		notification.setLatestEventInfo(context, context.getString(R.string.app_name), context.getResources().getString(R.string.notification), pi);

		notificationManager.notify(number, notification);
		number++;

	}

}
