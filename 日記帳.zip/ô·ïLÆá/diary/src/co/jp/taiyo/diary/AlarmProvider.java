package co.jp.taiyo.diary;

import java.util.Calendar;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;

/**
 * �A���[���ݒ�����Ă��܂�
 * @author kondo
 *
 */
public class AlarmProvider extends Activity implements OnTimeChangedListener{

	private AlarmManager alarmManager;
	private Calendar c;
	private final String className = "AlarmProvider";

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.alarm);
		setActionBar();

		TimePicker timePicker = (TimePicker) findViewById(R.id.timerpicker);
		c = Calendar.getInstance();

		//���݂̎������擾���܂�
		int nowHour = c.get(Calendar.HOUR_OF_DAY);
		int nowMinute = c.get(Calendar.MINUTE);

		//�s�b�J�[�̃f�t�H���g�l�Ƃ��āA���݂̎�����ݒ肵�܂�
		timePicker.setCurrentHour(nowHour);
		timePicker.setCurrentMinute(nowMinute);
		timePicker.setOnTimeChangedListener(this);


	}

	/**
	 * �^�C�g���o�[��ݒ肵�Ă��܂�
	 */
	private void setActionBar() {
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.action_bar5);

		//�J�X�^���^�C�g���̃Z�b�g�A�b�v
		TextView mTitle;
		mTitle = (TextView) findViewById(R.id.title_text);
		mTitle.setText(getString(R.string.app_name));

		//�{�^��
		Button mButton;
		mButton = (Button) findViewById(R.id.return_btn4);
		mButton.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {

				finish();

			}
		});

	}

	/**
	 * �^�C�}�[�Ŏ��ԕύX�����ꍇ�̏���
	 * @param timepicker �^�C�}�[�s�b�J�[
	 * @param hourOfDay ��
	 * @param minute ��
	 */
	public void onTimeChanged(TimePicker timepicker, int hourOfDay, int minute) {
		final String methodName = "onTimeChanged";

		Log.d(className, methodName + ":: hour =" + hourOfDay + " minute =" + minute);

		Intent i = new Intent(getApplicationContext(), ReceivedActivity.class);
		PendingIntent sender = PendingIntent.getBroadcast(AlarmProvider.this, 0, i, 0);

		c.set(Calendar.HOUR_OF_DAY, hourOfDay);
		c.set(Calendar.MINUTE, minute);

		alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarmManager.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), sender);

	}

}
